# Demo Playbook

Simple Ansible playbook to demonstrate how Ansible Semaphore works.
